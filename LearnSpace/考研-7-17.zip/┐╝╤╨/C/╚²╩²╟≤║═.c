#include <stdio.h>

int main(){
    int i;
    char j;
    float k;
    scanf("%d %c%f",&i,&j,&k);
    printf("%6.2f",i+j+k);
}