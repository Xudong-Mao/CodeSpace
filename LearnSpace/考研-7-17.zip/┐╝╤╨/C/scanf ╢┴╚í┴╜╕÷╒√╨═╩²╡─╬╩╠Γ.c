# include <stdio.h>

int main(){
    int a,b;
    scanf("%d%d",&a,&b); // 中间加不加空格都没有关系
    printf("%d\n",a+b);
}