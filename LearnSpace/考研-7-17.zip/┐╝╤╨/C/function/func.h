# include <stdio.h> // 头文件中放的是函数的声明

int printstar(int i); // 函数声明
void print_massage();