// ascll码转换
# include <stdio.h>

int main(){
    int c;
    scanf("%d",&c);
    printf("%c",c);
}