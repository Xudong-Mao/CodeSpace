# include <stdio.h>

int main(){
    printf("%s\n","just test!");
    printf("%s\n","just test!");
    printf("%s\n","just test!");
    return 0;
}