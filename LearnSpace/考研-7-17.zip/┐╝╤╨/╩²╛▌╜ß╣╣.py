import matplotlib.pyplot as plt
import numpy as np

x = np.array([1,2,3,4,5,6,7,8])
y = np.array([8,7,6,5,4,3,2,1])

plt.plot(x,y)
plt.show()